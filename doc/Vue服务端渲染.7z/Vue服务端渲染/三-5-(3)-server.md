```javascript
const webpack = require('webpack')
const {
    merge
} = require('webpack-merge')
const nodeExternals = require('webpack-node-externals')
const baseConfig = require('./webpack.base.config.js')
const VueSSRServerPlugin = require('vue-server-renderer/server-plugin')

module.exports = merge(baseConfig, {
    entry: '/src/entry-server.js',
    target: 'node',
    devtool: 'source-map',
    output: {
        libraryTarget: 'commonjs2'
    },
    externals: nodeExternals({
        allowlist: [/\.css$/]
    }),
    module: {
        rules: [{
            test: /\.(css|less)$/,
            use: ['vue-style-loader',
                'css-loader',
                'postcss-loader',
                'less-loader'
            ]
        }, ]
    },

    plugins: [
        new VueSSRServerPlugin(),
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'development'),
            'process.env.VUE_ENV': "'server'"
        }),
    ]
})
```

