```javascript
const webpack = require('webpack')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const {
	merge
} = require('webpack-merge')
const baseConfig = require('./webpack.base.config.js')
const VueSSRClientPlugin = require('vue-server-renderer/client-plugin')
const isProduction = process.env.NODE_ENV === 'production'
let config = merge(baseConfig, {
	entry: {
		app: '/src/entry-client.js'
	},
	optimization: {
		splitChunks: {
			chunks: 'initial',
			minSize: 30000,
			maxSize: 0,
			minChunks: 1,
			maxAsyncRequests: 5,
			maxInitialRequests: 3,
			automaticNameDelimiter: '~',
			name: '',
			 cacheGroups: {
				vendor: {
					test: /[\\/]node_modules[\\/]/,
					chunks: "all",
					priority: 10,
					enforce: true
				},
				commons: {
					chunks: "all",
					minChunks: 2,
					maxInitialRequests: 5,
					// minSize: 0,
					priority: 0
				}
			},
		},
		runtimeChunk: {
			name: "manifest"
		}
	},
	module: {
		rules: [{
			test: /\.(css|less)$/,
			use: [isProduction ? MiniCssExtractPlugin.loader : 'vue-style-loader',
				'css-loader',
				'postcss-loader',
				'less-loader'
			]
		}]
	},
	plugins: [
		new VueSSRClientPlugin(),
		new webpack.DefinePlugin({
			'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'development'),
			'process.env.VUE_ENV': "'client'"
		})
	]
})
if (isProduction) {
	config.plugins.push(new MiniCssExtractPlugin({
		filename: 'common.[chunkhash].css'//css文件名字
	}))
}
module.exports = config
```

